A sample GO web application with Dockerfile

