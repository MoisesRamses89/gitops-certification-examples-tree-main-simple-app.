# Codefresh GitOps Certification examples

This repository contains examples for the ArgoCD/GitOps
certification workshops.

Take the certification yourself at https://codefresh.io/courses/get-gitops-certified/
